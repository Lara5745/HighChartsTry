/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 *
 * Item series type for Highcharts
 *
 * (c) 2010-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/item-series.src.js';
